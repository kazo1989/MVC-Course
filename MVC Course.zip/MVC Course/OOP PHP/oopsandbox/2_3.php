<?php

// Define class

class User {

    // Prperties are attributes
    public $name;  


    // Methods are functions
    public function sayHello(){
        return $this->name . " says Hello !";
    }

}

// Instatiate a user object from the user class
$user1 = new User();

$user1->name = "Petar";

echo $user1->name;
echo "<br>";
echo $user1->sayHello();

echo "<br>";
echo "<br>";

// Create new user
$user2 = new User();

$user1->name = "Jakov";

echo $user1->name;
echo "<br>";
echo $user1->sayHello();
